import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiConstants {
  static String baseUrl = dotenv.env['BASE_URL']!;
  static String apiUrl = "$baseUrl/api/v1";
  static String imageBaseUrl = "$baseUrl/storage";


  // ------------------ AUTH Endpoints ------------------

  static const String sendOtp = "/auth/otp/send";
  static const String verifyOtp = "/auth/otp/verify";
  static const String me = "/auth/me";

  // ------------------ LOCATION Endpoints ------------------

  static const String validatePinCode = "/pincodes/validate";

  // ------------------ COMMON Endpoints ------------------
  static const String home = "/home";
  static const String categorySlug = "/categories/{slug}";


  // Headers
  static const String contentType = 'application/json';
  static const String authorization = 'Authorization';
  static const String acceptLanguage = 'Accept-Language';

  //Timeouts
  static const int connectTimerOutsMs = 30000;
  static const int receiveTimerOutsMs = 30000;
  static const int sendTimerOutsMs = 30000;
}
