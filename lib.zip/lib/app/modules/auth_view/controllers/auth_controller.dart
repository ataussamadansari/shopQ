import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopq/app/core/utils/helpers.dart';
import 'package:shopq/app/routes/app_routes.dart';
import '../../../data/repositories/auth/auth_repository.dart';
import '../../../data/services/storage/storage_services.dart';

class AuthController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final AuthRepository _authRepo = AuthRepository();
  final StorageServices _storage = Get.find();

  late AnimationController animationController;

  final isOtpSent = false.obs;
  final isLoading = false.obs;
  final hasError = false.obs;
  final errorMessage = "".obs;

  final phoneController = TextEditingController();
  final otpController = TextEditingController();

  var phoneText = "".obs;
  var otpText = "".obs;

  @override
  void onInit() {
    super.onInit();

    animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat(reverse: true);

    phoneController.addListener(() {
      phoneText.value = phoneController.text;
    });

    otpController.addListener(() {
      otpText.value = otpController.text;
    });
  }

  bool get isValidPhone => phoneText.value.length == 10;

  bool get isValidOtp => otpText.value.length == 6;

  bool get isButtonEnabled => !isOtpSent.value ? isValidPhone : isValidOtp;

  Future<void> onContinuePressed() async {
    if (!isButtonEnabled || isLoading.value) return;

    if (!isOtpSent.value) {
      await _sendOtp();
    } else {
      await _verifyOtp();
    }
  }

  // 🔥 SEND OTP CONNECTED
  Future<void> _sendOtp() async {
    try {
      isLoading.value = true;
      hasError.value = false;

      final response = await _authRepo.sendOtp(phoneController.text);

      if (response.success) {
        isOtpSent.value = true;
        debugPrint("Send OTP: ${response.message}");
        AppHelpers.showSnackBar(
          message: response.message,
          title: 'Success',
          isError: false,
        );
      } else {
        hasError.value = true;
        errorMessage.value = response.message;

        debugPrint("Send OTP: ${response.message}");

        AppHelpers.showSnackBar(
          message: response.message,
          title: 'Error',
          isError: true,
        );
      }
    } on DioException catch (e) {
      hasError.value = true;
      errorMessage.value = e.message!;
      debugPrint("Send OTP Error: ${e.message}");
      AppHelpers.showSnackBar(
        message: e.message!,
        title: 'Catch Error',
        isError: true,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // 🔥 VERIFY OTP CONNECTED
  Future<void> _verifyOtp() async {
    try {
      isLoading.value = true;
      hasError.value = false;

      final response = await _authRepo.verifyOtp(
        phoneController.text,
        otpController.text,
      );

      if (response.success && response.data != null) {
        debugPrint("Verify OTP: ${response.message}");

        // 🔐 Save token
        _storage.setToken(response.data!.token!);

        Get.offAllNamed(Routes.location);
      } else {
        hasError.value = true;
        errorMessage.value = response.message;
        debugPrint("Invalid OTP: ${response.message}");

        AppHelpers.showSnackBar(
          message: response.message,
          title: 'Error',
          isError: true,
        );
      }
    } on DioException catch (e) {
      hasError.value = true;
      errorMessage.value = e.message!;
      debugPrint("Error: ${e.message}");
      AppHelpers.showSnackBar(
        message: e.message!,
        title: 'Catch Error',
        isError: true,
      );
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    animationController.dispose();
    phoneController.dispose();
    otpController.dispose();
    super.onClose();
  }
}
