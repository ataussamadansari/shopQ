import 'package:get/get.dart';
import '../../../data/models/home/section_item.dart';
import '../../../data/models/category/sub_category.dart';
import '../../../data/repositories/category/category_repository.dart';

class CategoryController extends GetxController {

  final CategoryRepository _repository = CategoryRepository();

  late SectionItem parentCategory;

  RxList<SectionItem> leftCategories = <SectionItem>[].obs;
  RxList<SectionItem> rightCategories = <SectionItem>[].obs;

  RxInt selectedLeftId = 0.obs;
  RxInt selectedRightId = 0.obs;

  RxList<Products> products = <Products>[].obs;

  RxBool isLoading = false.obs;
  RxString errorMessage = ''.obs;

  final String pinCode = "221307";

  @override
  void onInit() {
    super.onInit();

    parentCategory = Get.arguments as SectionItem;

    final allItem = SectionItem.fromJson({
      "id": parentCategory.id,
      "name": "All",
      "slug": parentCategory.slug,
      "featured_image": parentCategory.featuredImage,
    });

    leftCategories.value = [
      allItem,
      ...(parentCategory.children ?? [])
    ];

    selectLeftCategory(allItem);
  }

  Future<void> selectLeftCategory(SectionItem item) async {

    if (selectedLeftId.value == item.id) return;

    selectedLeftId.value = item.id ?? 0;
    selectedRightId.value = 0;

    await loadCategory(item.slug ?? "");
  }

  Future<void> selectRightCategory(SectionItem item) async {

    if (selectedRightId.value == item.id) return;

    selectedRightId.value = item.id ?? 0;

    await loadCategory(item.slug ?? "");
  }

  Future<void> loadCategory(String slug) async {

    if (slug.isEmpty) return;

    try {
      isLoading.value = true;
      errorMessage.value = '';

      products.clear();
      rightCategories.clear();

      final response = await _repository.home(pinCode, slug);

      if (response.success && response.data != null) {

        final data = response.data!.data;

        if (data?.category?.children != null) {
          rightCategories.value = data!.category!.children!
              .map((e) => SectionItem.fromJson(e.toJson()))
              .toList();
        }

        products.value = data?.products ?? [];
      }

    } finally {
      isLoading.value = false;
    }
  }
}