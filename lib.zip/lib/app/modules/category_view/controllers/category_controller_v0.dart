import 'package:get/get.dart';
import '../../../data/models/home/section_item.dart';

class CategoryController extends GetxController {

  late SectionItem parentCategory;

  RxList<SectionItem> subCategories = <SectionItem>[].obs;
  Rx<SectionItem?> selectedSubCategory = Rx<SectionItem?>(null);

  @override
  void onInit() {
    super.onInit();

    final args = Get.arguments as SectionItem;

    parentCategory = args;

    subCategories.value = parentCategory.children ?? [];

    if (subCategories.isNotEmpty) {
      selectedSubCategory.value = subCategories.first;
    }
  }

  void selectSubCategory(SectionItem item) {
    if (selectedSubCategory.value?.id != item.id) {
      selectedSubCategory.value = item;
    }
  }
}