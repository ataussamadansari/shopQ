import 'package:get/get.dart';
import '../../../data/models/home/section_item.dart';
import '../../../data/models/category/sub_category.dart';
import '../../../data/repositories/category/category_repository.dart';

class CategoryController extends GetxController {
  final CategoryRepository _repository = CategoryRepository();

  late SectionItem parentCategory;

  RxList<SectionItem> leftCategories = <SectionItem>[].obs;
  // RxList<SectionItem> rightCategories = <SectionItem>[].obs;

  // Selected states
  Rx<SectionItem?> selectedLeft = Rx<SectionItem?>(null);
  Rx<SectionItem?> selectedRight = Rx<SectionItem?>(null);

  RxList<Products> products = <Products>[].obs;
  RxBool isLoading = false.obs;
  RxString errorMessage = ''.obs;

  final String pinCode = "221307";

  @override
  void onInit() {
    super.onInit();
    if (Get.arguments is SectionItem) {
      parentCategory = Get.arguments as SectionItem;

      final allItem = SectionItem.fromJson({
        "id": parentCategory.id,
        "name": "All",
        "slug": parentCategory.slug,
        "featured_image": parentCategory.featuredImage,
      });

      leftCategories.assignAll([allItem, ...(parentCategory.children ?? [])]);

      // Default selection
      selectLeftCategory(allItem);
    }
  }

  Future<void> selectLeftCategory(SectionItem item) async {
    // ID base comparison for stability
    selectedLeft.value = item;
    selectedRight.value = null; // Reset right filter

    await loadCategory(item.slug ?? "", updateChips: true);

    // Refresh UI specifically for list state
    leftCategories.refresh();
  }

  Future<void> selectRightCategory(SectionItem item) async {
    selectedRight.value = item;
    await loadCategory(item.slug ?? "", updateChips: false);
  }

  Future<void> loadCategory(String slug, {required bool updateChips}) async {
    if (slug.isEmpty) return;

    try {
      isLoading.value = true;
      errorMessage.value = '';
      // if (updateChips) rightCategories.clear();
      products.clear();

      final response = await _repository.home(pinCode, slug);

      if (response.success && response.data != null) {
        final data = response.data!.data;

        /*if (updateChips && data?.category?.children != null) {
          rightCategories.value = data!.category!.children!
              .map((e) => SectionItem.fromJson(e.toJson()))
              .toList();
        }*/
        products.value = data?.products ?? [];
      } else {
        errorMessage.value = response.message;
      }
    } catch (e) {
      errorMessage.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }
}