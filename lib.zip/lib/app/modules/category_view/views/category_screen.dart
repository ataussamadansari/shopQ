import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/category_controller.dart';
import '../../../global_widgets/product_card_slug.dart';

class CategoryScreen extends GetView<CategoryController> {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Obx(() => Text(controller.selectedLeft.value?.name ?? "Category")),
      ),
      body: Row(
        children: [
          /// 🔹 LEFT SIDE (Category List)
          Container(
            width: 100,
            color: Colors.grey.shade100,
            child: Obx(() {
              return ListView.builder(
                itemCount: controller.leftCategories.length,
                itemBuilder: (context, index) {
                  final item = controller.leftCategories[index];

                  // 🔥 Logic: ID match use karo reference ki jagah
                  final isSelected = controller.selectedLeft.value?.id == item.id;

                  return InkWell(
                    onTap: () => controller.selectLeftCategory(item),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.white : Colors.transparent,
                        border: Border(
                          left: BorderSide(
                            color: isSelected ? Colors.blue : Colors.transparent,
                            width: 4,
                          ),
                        ),
                      ),
                      child: Column(
                        children: [
                          if (item.featuredImage != null)
                            Image.network(
                              item.featuredImage!,
                              height: 40, width: 40,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(Icons.image),
                            ),
                          const SizedBox(height: 6),
                          Text(
                            item.name ?? "",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                              color: isSelected ? Colors.blue : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),

          /// 🔹 RIGHT SIDE (Chips + Products)
          Expanded(
            child: Column(
              children: [
                // Horizontal Chips
                /*Obx(() => controller.rightCategories.isNotEmpty
                    ? Container(
                  height: 55,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    scrollDirection: Axis.horizontal,
                    itemCount: controller.rightCategories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final item = controller.rightCategories[index];
                      final isChipSelected = controller.selectedRight.value?.id == item.id;

                      return ChoiceChip(
                        label: Text(item.name ?? ""),
                        selected: isChipSelected,
                        selectedColor: Colors.blue.shade100,
                        onSelected: (_) => controller.selectRightCategory(item),
                      );
                    },
                  ),
                )
                    : const SizedBox.shrink()),*/

                // Products Grid
                Expanded(
                  child: Obx(() {
                    if (controller.isLoading.value && controller.products.isEmpty) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (controller.products.isEmpty) {
                      return const Center(child: Text("No products found"));
                    }
                    return GridView.builder(
                      padding: const EdgeInsets.all(10),
                      itemCount: controller.products.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 0.58,
                      ),
                      itemBuilder: (context, index) =>
                          ProductCardSlug(product: controller.products[index]),
                    );
                  }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
