import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/category_controller_v2.dart';
import '../../../global_widgets/product_card_slug.dart';

class CategoryScreen extends GetView<CategoryController> {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(controller.parentCategory.name ?? "Category"),
      ),
      body: Row(
        children: [

          /// 🔹 LEFT SIDE
          Container(
            width: 100,
            color: Colors.grey.shade100,
            child: Obx(() => ListView.builder(
              itemCount: controller.leftCategories.length,
              itemBuilder: (context, index) {

                final item = controller.leftCategories[index];

                final isSelected =
                    controller.selectedLeftId.value == item.id;

                debugPrint("debug: id= ${item.id} == controllerLeft: ${controller.selectedLeftId.value}");

                return InkWell(
                  onTap: () => controller.selectLeftCategory(item),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 8),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? Colors.white
                          : Colors.grey.shade100,
                      border: Border(
                        left: BorderSide(
                          color: isSelected
                              ? Colors.blue
                              : Colors.transparent,
                          width: 3,
                        ),
                      ),
                    ),
                    child: Column(
                      children: [
                        if (item.featuredImage != null)
                          Image.network(
                            item.featuredImage!,
                            height: 40,
                            width: 40,
                            fit: BoxFit.cover,
                          ),
                        const SizedBox(height: 6),
                        Text(
                          item.name ?? "",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            )),
          ),

          /// 🔹 RIGHT SIDE
          Expanded(
            child: Obx(() {

              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.errorMessage.isNotEmpty) {
                return Center(child: Text(controller.errorMessage.value));
              }

              return Column(
                children: [

                  /// 🔥 RIGHT CHIPS
                  if (controller.rightCategories.isNotEmpty)
                    SizedBox(
                      height: 50,
                      child: ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        scrollDirection: Axis.horizontal,
                        itemCount: controller.rightCategories.length,
                        separatorBuilder: (_, __) =>
                        const SizedBox(width: 8),
                        itemBuilder: (context, index) {

                          final item =
                          controller.rightCategories[index];

                          final isSelected =
                              controller.selectedRightId.value == item.id;

                          return ChoiceChip(
                            label: Text(item.name ?? ""),
                            selected: isSelected,
                            selectedColor:
                            Colors.blue.shade100,
                            onSelected: (_) =>
                                controller.selectRightCategory(item),
                          );
                        },
                      ),
                    ),

                  /// 🔥 PRODUCTS
                  Expanded(
                    child: controller.products.isEmpty
                        ? const Center(child: Text("No Products"))
                        : GridView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount:
                      controller.products.length,
                      gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.58,
                      ),
                      itemBuilder: (context, index) {
                        final product =
                        controller.products[index];
                        return ProductCardSlug(product: product);
                      },
                    ),
                  ),
                ],
              );
            }),
          ),
        ],
      ),
    );
  }
}
