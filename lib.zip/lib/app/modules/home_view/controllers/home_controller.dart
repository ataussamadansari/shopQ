import 'package:flutter/material.dart';
import 'package:get/get.dart';

// ═══════════════════════════════════════════════════════════════════
//  MODELS
// ═══════════════════════════════════════════════════════════════════

class TabItem {
  final String title;
  final String image;
  final Color color;
  TabItem({required this.title, required this.image, required this.color});
}

class ProductItem {
  final String name;
  final String weight;
  final String price;
  final String mrp;
  final String off;
  final String imageUrl;
  final bool isOfferPrice; // shows lock+offer badge like blinkit
  const ProductItem({
    required this.name,
    required this.weight,
    required this.price,
    required this.mrp,
    required this.off,
    required this.imageUrl,
    this.isOfferPrice = false,
  });
}

// CategoryType drives which UI is used
enum CategoryType { fruitVeg, standard }

class CategoryItem {
  final String title;
  final String imageUrl;
  final Color bgColor;
  final CategoryType type;
  const CategoryItem({
    required this.title,
    required this.imageUrl,
    required this.bgColor,
    this.type = CategoryType.standard,
  });
}

class StoreItem {
  final String title;
  final String imageUrl;
  const StoreItem({required this.title, required this.imageUrl});
}

class BannerItem {
  final String imageUrl;
  final String? title;
  final String? subtitle;
  final Color bgColor;
  const BannerItem({
    required this.imageUrl,
    this.title,
    this.subtitle,
    required this.bgColor,
  });
}

// ═══════════════════════════════════════════════════════════════════
//  HOME CONTROLLER  — all data lives here
// ═══════════════════════════════════════════════════════════════════
class HomeController extends GetxController {
  // ── Tabs ────────────────────────────────────────────────────────
  List<TabItem> tabs = [];
  int selectedIndex = 0;

  // ── Infinite scroll ─────────────────────────────────────────────
  bool isLoadingMore = false;
  int _extraPagesLoaded = 0;
  static const int _maxExtraPages = 5;

  // ── Page data ───────────────────────────────────────────────────
  List<ProductItem> handpickedProducts = [];
  List<ProductItem> coldDrinksProducts = [];
  List<ProductItem> dealsProducts = [];
  List<ProductItem> bestSellingProducts = [];
  List<ProductItem> youMayLikeProducts = [];

  List<CategoryItem> fruitVegCategories = [];
  List<CategoryItem> dairyCategories = [];
  List<CategoryItem> groceryCategories = [];
  List<CategoryItem> snacksCategories = [];
  List<CategoryItem> beautyCategories = [];
  List<CategoryItem> cleaningCategories = [];

  List<StoreItem> stores = [];

  List<BannerItem> banners = [];

  // ── Helpers ─────────────────────────────────────────────────────
  Color get activeColor =>
      tabs.isNotEmpty ? tabs[selectedIndex].color : const Color(0xFF5CB8E4);

  @override
  void onInit() {
    super.onInit();
    _loadAll();
  }

  Future<void> _loadAll() async {
    await Future.delayed(const Duration(seconds: 1));
    _loadTabs();
    _loadProducts();
    _loadCategories();
    _loadStores();
    _loadBanners();
    update();
  }

  void _loadTabs() {
    tabs = [
      TabItem(title: "All",     image: "https://pics.freeicons.io/uploads/icons/png/16051444861606988091-512.png", color: const Color(0xFF5CB8E4)),
      TabItem(title: "Ramadan", image: "https://pics.freeicons.io/uploads/icons/png/6351714491692699105-512.png", color: const Color(0xFF2E7D32)),
      TabItem(title: "Deals",   image: "https://pics.freeicons.io/uploads/icons/png/11151643681535797978-512.png", color: const Color(0xFFF9A825)),
      TabItem(title: "Fresh",   image: "https://cdn-icons-png.flaticon.com/512/415/415733.png",   color: const Color(0xFF388E3C)),
      TabItem(title: "Rice",    image: "https://cdn-icons-png.flaticon.com/512/2553/2553651.png", color: const Color(0xFFE65100)),
      TabItem(title: "Snacks",  image: "https://cdn-icons-png.flaticon.com/512/2553/2553691.png", color: const Color(0xFF6A1B9A)),
      TabItem(title: "Beauty",  image: "https://pics.freeicons.io/uploads/icons/png/12698951411639799799-512.png", color: const Color(0xFFAD1457)),
    ];
  }

  void _loadProducts() {
    handpickedProducts = [
      const ProductItem(name: 'White Crystal Sugar Loose', weight: '1 Kg', price: '₹48', mrp: '₹60', off: '20%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      const ProductItem(name: 'Tata Salt', weight: '1 kg', price: '₹29', mrp: '₹30', off: '₹1', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      const ProductItem(name: 'Pyaz (Onion)', weight: '1 kg', price: '₹25', mrp: '₹49', off: '49%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png'),
      const ProductItem(name: 'Wheat Atta', weight: '1 Kg', price: '₹36', mrp: '₹60', off: '40%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png'),
      const ProductItem(name: 'Amul Malai Paneer Fresh', weight: '200 g', price: '₹89', mrp: '₹92', off: '₹3', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png', isOfferPrice: true),
      const ProductItem(name: 'Amul Shakti Milk', weight: '500 ml', price: '₹31', mrp: '₹35', off: '₹11', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553616.png', isOfferPrice: true),
    ];

    coldDrinksProducts = [
      const ProductItem(name: 'Slice Thickest Mango Drink', weight: '1.75 L', price: '₹84', mrp: '₹94', off: '11%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      const ProductItem(name: 'Mango Sip Juice Pet Bottle', weight: '1200 ml', price: '₹42', mrp: '₹85', off: '51%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      const ProductItem(name: '7Up 2.25 Ltr Pack of 1', weight: '2.25 L', price: '₹85', mrp: '₹100', off: '15%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png'),
      const ProductItem(name: 'Coca Cola', weight: '1.25 L', price: '₹65', mrp: '₹80', off: '19%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png'),
    ];

    dealsProducts = [
      const ProductItem(name: 'Kapiva Kerala Virgin Coconut Oil', weight: '250 ml', price: '₹230', mrp: '₹279', off: '18%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      const ProductItem(name: 'Kapiva A2 Desi Ghee', weight: '500 ml', price: '₹702', mrp: '₹1405', off: '50%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      const ProductItem(name: 'Mothers Recipe Red Chilli Pickle', weight: '200 g', price: '₹77', mrp: '₹80', off: '₹3', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553616.png'),
      const ProductItem(name: 'Parle Marie Biscuits 4 Pack', weight: '800 g', price: '₹105', mrp: '₹205', off: '49%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png'),
    ];

    bestSellingProducts = [
      const ProductItem(name: 'Dabur Chyawanprash', weight: '3x', price: '₹299', mrp: '₹399', off: '6%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      const ProductItem(name: 'Saffola Honey', weight: '500g', price: '₹185', mrp: '₹210', off: '50%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      const ProductItem(name: 'Mixer Grinder', weight: '750W', price: '₹2499', mrp: '₹4999', off: '49%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/1041/1041880.png'),
      const ProductItem(name: 'Tata Salt Pack', weight: '2 kg', price: '₹48', mrp: '₹56', off: '14%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png'),
    ];

    youMayLikeProducts = [
      const ProductItem(name: 'Amul Butter', weight: '100g', price: '₹55', mrp: '₹62', off: '11%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png'),
      const ProductItem(name: 'Fortune Refined Oil', weight: '1 L', price: '₹135', mrp: '₹170', off: '20%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      const ProductItem(name: 'Maggi Noodles 12 Pack', weight: '720g', price: '₹139', mrp: '₹180', off: '23%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      const ProductItem(name: 'Tata Tea Premium', weight: '250g', price: '₹105', mrp: '₹130', off: '19%', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png'),
    ];
  }

  void _loadCategories() {
    fruitVegCategories = const [
      CategoryItem(title: 'Fruits',         imageUrl: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400&q=80', bgColor: Color(0xFFE8F5E9), type: CategoryType.fruitVeg),
      CategoryItem(title: 'Vegetables',     imageUrl: 'https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?w=400&q=80', bgColor: Color(0xFFE8F5E9), type: CategoryType.fruitVeg),
      CategoryItem(title: 'Onion & Potato', imageUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80', bgColor: Color(0xFFFFF8E1), type: CategoryType.fruitVeg),
    ];

    dairyCategories = const [
      CategoryItem(title: 'Milk & Fresh',        imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png', bgColor: Color(0xFFE3F2FD)),
      CategoryItem(title: 'Bread & Buns',        imageUrl: 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png', bgColor: Color(0xFFFFF3E0)),
      CategoryItem(title: 'Breakfast & Cereals', imageUrl: 'https://cdn-icons-png.flaticon.com/512/1046/1046784.png', bgColor: Color(0xFFFCE4EC)),
      CategoryItem(title: 'Jams & Spreads',      imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553616.png', bgColor: Color(0xFFF3E5F5)),
    ];

    groceryCategories = const [
      CategoryItem(title: 'Atta, Besan & Sooji',   imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png', bgColor: Color(0xFFFFF8E1)),
      CategoryItem(title: 'Oils & Ghee',            imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png', bgColor: Color(0xFFFFF3E0)),
      CategoryItem(title: 'Pulses',                 imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png', bgColor: Color(0xFFE8F5E9)),
      CategoryItem(title: 'Cereals & Rice',         imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png',  bgColor: Color(0xFFFCE4EC)),
      CategoryItem(title: 'Dry Fruits & Nuts',      imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png', bgColor: Color(0xFFFFF8E1)),
      CategoryItem(title: 'Salt, Sugar & Jaggery',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png', bgColor: Color(0xFFFFF3E0)),
      CategoryItem(title: 'Masala & Spices',        imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png', bgColor: Color(0xFFFCE4EC)),
      CategoryItem(title: 'Pickles & Papad',        imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png',  bgColor: Color(0xFFE8F5E9)),
    ];

    snacksCategories = const [
      CategoryItem(title: 'Chips & Namkeen',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png', bgColor: Color(0xFFFFF3E0)),
      CategoryItem(title: 'Cold Drinks',      imageUrl: 'https://cdn-icons-png.flaticon.com/512/1046/1046784.png', bgColor: Color(0xFFE3F2FD)),
      CategoryItem(title: 'Biscuits & Cakes', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png', bgColor: Color(0xFFFCE4EC)),
      CategoryItem(title: 'Tea & Coffee',     imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png', bgColor: Color(0xFFF3E5F5)),
    ];

    beautyCategories = const [
      CategoryItem(title: 'Soaps & Body Wash', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553616.png', bgColor: Color(0xFFFCE4EC)),
      CategoryItem(title: 'Skin & Face Care',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153733.png', bgColor: Color(0xFFE8F5E9)),
      CategoryItem(title: 'Hair Care',         imageUrl: 'https://cdn-icons-png.flaticon.com/512/1041/1041880.png', bgColor: Color(0xFFE3F2FD)),
      CategoryItem(title: 'Dental Care',       imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png', bgColor: Color(0xFFF3E5F5)),
    ];

    cleaningCategories = const [
      CategoryItem(title: 'Detergent',       imageUrl: 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png', bgColor: Color(0xFFE8F5E9)),
      CategoryItem(title: 'Dishwash & Bars', imageUrl: 'https://cdn-icons-png.flaticon.com/512/1046/1046784.png', bgColor: Color(0xFFFFF3E0)),
      CategoryItem(title: 'Floor Cleaners',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png', bgColor: Color(0xFFE3F2FD)),
      CategoryItem(title: 'Cleaning Tools',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/2674/2674539.png', bgColor: Color(0xFFFCE4EC)),
    ];
  }

  void _loadStores() {
    stores = const [
      StoreItem(title: 'Kitchen Care',     imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553691.png'),
      StoreItem(title: 'Cleaning',         imageUrl: 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png'),
      StoreItem(title: 'Pooja Store',      imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png'),
      StoreItem(title: 'Pet Store',        imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png'),
      StoreItem(title: 'Home Furnishing',  imageUrl: 'https://cdn-icons-png.flaticon.com/512/1041/1041880.png'),
      StoreItem(title: 'Electronic Store', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553651.png'),
      StoreItem(title: 'Premium Store',    imageUrl: 'https://cdn-icons-png.flaticon.com/512/2553/2553616.png'),
      StoreItem(title: 'Stationery Store', imageUrl: 'https://cdn-icons-png.flaticon.com/512/2153/2153733.png'),
    ];
  }

  void _loadBanners() {
    banners = const [
      BannerItem(
        imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80',
        title: 'GET FLAT ₹50 OFF',
        subtitle: 'on your first order, on shopping of ₹399',
        bgColor: Color(0xFFFFF3E0),
      ),
      BannerItem(
        imageUrl: 'https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=800&q=80',
        title: 'We Deliver 26 kgs Rice Bags!',
        subtitle: 'Order Now!',
        bgColor: Color(0xFFFFF8E1),
      ),
      BannerItem(
        imageUrl: 'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=800&q=80',
        title: 'Bachat Bazaar',
        subtitle: '10 MINS DELIVERY',
        bgColor: Color(0xFF1B5E20),
      ),
    ];
  }

  void changeTab(int index) {
    selectedIndex = index;
    update();
  }

  Future<void> loadMoreIfNeeded() async {
    if (isLoadingMore || _extraPagesLoaded >= _maxExtraPages) return;
    isLoadingMore = true;
    update();
    await Future.delayed(const Duration(milliseconds: 1200));
    _extraPagesLoaded++;
    isLoadingMore = false;
    update();
  }

  Color lighten(Color color, [double amount = .2]) {
    final hsl = HSLColor.fromColor(color);
    final hslLight = hsl.withLightness(
      (hsl.lightness + amount).clamp(0.0, 1.0),
    );
    return hslLight.toColor();
  }

  Color darken(Color color, [double amount = .2]) {
    final hsl = HSLColor.fromColor(color);
    final hslDark = hsl.withLightness(
      (hsl.lightness - amount).clamp(0.0, 1.0),
    );
    return hslDark.toColor();
  }
}