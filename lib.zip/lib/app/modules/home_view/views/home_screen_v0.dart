import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../global_widgets/offer_strip_widget.dart';
import '../controllers/home_controller_v0.dart';
import 'widgets/category_chips_widget.dart';
import 'widgets/category_grid_widget.dart';
import 'widgets/custom_banner_widgets.dart';
import 'widgets/custom_search_tabs.dart';
import 'widgets/product_carousal_widget.dart';

class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final topInset = MediaQuery.paddingOf(context).top;

      if (controller.isLoading.value && controller.homeData.value == null) {
        return const Scaffold(
          backgroundColor: Color(0xFFF7F4EC),
          body: SafeArea(child: _HomeLoadingView()),
        );
      }

      if (controller.hasError.value && controller.homeData.value == null) {
        return Scaffold(
          backgroundColor: const Color(0xFFF7F4EC),
          body: SafeArea(
            child: _HomeErrorView(
              message: controller.errorMessage.value,
              onRetry: controller.fetchHome,
            ),
          ),
        );
      }

      return Scaffold(
        body: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: topInset,
              child: const ColoredBox(color: Colors.indigo),
            ),
            SafeArea(
              bottom: false,
              child: RefreshIndicator(
                color: Colors.indigo,
                onRefresh: controller.fetchHome,
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  slivers: [
                    SliverToBoxAdapter(
                      child: _HomeHeader(pinCode: controller.activePinCode),
                    ),
                    CustomSearchTabs(tabs: controller.tabs),
                    if (controller.sections.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _HomeEmptyView(onRetry: controller.fetchHome),
                      )
                    else ...[
                      const SliverToBoxAdapter(child: SizedBox(height: 14)),
                      ...controller.sections.map((section) {
                        switch (section.type) {
                          case "banner_slider":
                            return CustomBannerWidget(
                              title: section.title ?? "",
                              subtitle: section.subtitle,
                              banners: section.items ?? [],
                            );
                          case "category_chips":
                            return CategoryChipsWidget(
                              categories: section.items ?? [],
                              title: section.title ?? "",
                              subtitle: section.subtitle,
                            );
                          case "product_carousel":
                            return ProductCarouselWidget(
                              products: section.items ?? [],
                              title: section.title ?? "",
                              subtitle: section.subtitle,
                            );
                          case "category_grid":
                            return CategoryGridWidget(
                              categories: section.items ?? [],
                              title: section.title ?? "",
                              subtitle: section.subtitle,
                            );
                          case "offer_strip":
                            return OfferStripWidget(
                              title: section.title ?? "",
                              subtitle: section.subtitle ?? "",
                              offer: section.offer,
                            );
                          default:
                            return const SliverToBoxAdapter(child: SizedBox());
                        }
                      }),



                      const SliverToBoxAdapter(child: SizedBox(height: 28)),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class _HomeHeader extends StatelessWidget {
  final String pinCode;

  const _HomeHeader({required this.pinCode});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.indigo,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: const [
                        Text(
                          "Home",
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(width: 4),
                        Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.white,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Service available for pincode $pinCode",
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 44,
                height: 44,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.person_outline_rounded,
                  color: Color(0xFF1D1D1B),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
        ],
      ),
    );
  }
}

class _HomeLoadingView extends StatelessWidget {
  const _HomeLoadingView();

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: const [
        _LoadingBlock(
          height: 170,
          margin: EdgeInsets.fromLTRB(16, 12, 16, 16),
          borderRadius: 28,
          color: Colors.indigo,
        ),
        _LoadingBlock(
          height: 110,
          margin: EdgeInsets.symmetric(horizontal: 16),
          borderRadius: 28,
          color: Colors.white,
        ),
        _LoadingBlock(
          height: 190,
          margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
          borderRadius: 24,
          color: Colors.white,
        ),
        _LoadingBlock(
          height: 140,
          margin: EdgeInsets.fromLTRB(16, 18, 16, 0),
          borderRadius: 24,
          color: Colors.white,
        ),
      ],
    );
  }
}

class _LoadingBlock extends StatelessWidget {
  final double height;
  final EdgeInsets margin;
  final double borderRadius;
  final Color color;

  const _LoadingBlock({
    required this.height,
    required this.margin,
    required this.borderRadius,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      margin: margin,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(borderRadius),
      ),
    );
  }
}

class _HomeErrorView extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;

  const _HomeErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFFE8E3D7)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.cloud_off_rounded,
                size: 42,
                color: Colors.indigo,
              ),
              const SizedBox(height: 14),
              const Text(
                "Unable to load home",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Text(
                message.isNotEmpty
                    ? message
                    : "Pull to refresh or try again in a moment.",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Color(0xFF6F6B62)),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  onRetry();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                ),
                child: const Text("Retry"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeEmptyView extends StatelessWidget {
  final Future<void> Function() onRetry;

  const _HomeEmptyView({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.storefront_outlined,
              size: 44,
              color: Colors.indigo,
            ),
            const SizedBox(height: 14),
            const Text(
              "No sections available yet",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text(
              "Refresh once the home payload is ready for this pincode.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Color(0xFF6F6B62)),
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: () {
                onRetry();
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.indigo,
                side: const BorderSide(color: Colors.indigo),
              ),
              child: const Text("Refresh"),
            ),
          ],
        ),
      ),
    );
  }
}
