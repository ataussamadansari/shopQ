import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';

// ═══════════════════════════════════════════════════════════════════
//  PINNED HEADER DELEGATE
// ═══════════════════════════════════════════════════════════════════
class _PinnedHeaderDelegate extends SliverPersistentHeaderDelegate {
  final HomeController controller;

  final double scrollOffset;
  final int selectedTab;
  final ValueChanged<int> onTabSelected;
  final List<TabItem> tabs;
  final double statusBarHeight;

  const _PinnedHeaderDelegate({
    required this.controller,
    required this.scrollOffset,
    required this.selectedTab,
    required this.onTabSelected,
    required this.tabs,
    required this.statusBarHeight,
  });

  // search(46) + gap(4) + tabs(64) + innerPad(10) = 124
  static const double _contentHeight = 124.0;

  @override double get maxExtent => statusBarHeight + _contentHeight;
  @override double get minExtent => statusBarHeight + _contentHeight;

  double get _t => (scrollOffset / 80).clamp(0.0, 1.0);
  Color get _activeColor =>
      tabs.isNotEmpty ? tabs[selectedTab].color : const Color(0xFF5CB8E4);

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final bg = Color.lerp(_activeColor, _activeColor, _t)!;
    final isScrolled = _t > 0.05;
    // final Color selIcon   = isScrolled ? Colors.white : _activeColor;
    final Color selIcon   = Colors.white;
    final Color unselIcon = isScrolled ? Colors.white70 : Colors.black54;
    // final Color selLabel  = isScrolled ? Colors.white : _activeColor;
    final Color selLabel  = Colors.white;
    final Color unselLbl  = isScrolled ? Colors.white70 : Colors.black87;
    // final Color lineColor = isScrolled ? Colors.white : _activeColor;
    /*final Color lineColor = isScrolled
        ? Colors.white
        : controller.lighten(_activeColor, 0.2);*/

    final Color lineColor = isScrolled
        ? Colors.white
        : (_activeColor.computeLuminance() > 0.5
        ? controller.darken(_activeColor, 0.3)
        : controller.lighten(_activeColor, 0.3));


    return Container(
      color: bg,
      padding: EdgeInsets.fromLTRB(12, statusBarHeight + 10, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search bar
          Container(
            height: 46,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: isScrolled
                  ? [const BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 2))]
                  : [],
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.search, color: Color(0xFF9E9E9E), size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('Search for "Milk"',
                      style: TextStyle(color: Colors.grey.shade400, fontSize: 14)),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                  width: 1,
                  color: Colors.grey.shade300,
                ),
                const Icon(Icons.mic_outlined, color: Color(0xFF9E9E9E), size: 20),
                const SizedBox(width: 12),
              ],
            ),
          ),
          const SizedBox(height: 4),
          // Tabs
          SizedBox(
            height: 64,
            child: tabs.isEmpty
                ? const SizedBox()
                : ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: tabs.length,
              itemBuilder: (context, i) {
                final tab = tabs[i];
                final isSel = i == selectedTab;
                return GestureDetector(
                  onTap: () => onTabSelected(i),
                  child: Container(
                    margin: const EdgeInsets.only(right: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: isSel && isScrolled
                                ? Colors.white.withOpacity(0.2)
                                : Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                          child: Image.network(
                            tab.image,
                            width: 26,
                            height: 26,
                            fit: BoxFit.contain,
                            colorBlendMode: BlendMode.srcIn,
                            errorBuilder: (_, __, ___) => Icon(
                              Icons.category_outlined,
                              size: 24,
                              color: isSel ? selIcon : unselIcon,
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(tab.title,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: isSel ? FontWeight.w700 : FontWeight.w400,
                                color: isSel ? selLabel : unselLbl)),
                        const SizedBox(height: 2),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: 3,
                          width: isSel ? 40 : 0,
                          decoration: BoxDecoration(
                              color: lineColor,
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(_PinnedHeaderDelegate old) =>
      old.scrollOffset != scrollOffset ||
          old.selectedTab != selectedTab ||
          old.statusBarHeight != statusBarHeight ||
          old.tabs.length != tabs.length;
}

// ═══════════════════════════════════════════════════════════════════
//  FLOATING APP BAR
// ═══════════════════════════════════════════════════════════════════
class _FloatingAppBar extends StatelessWidget {
  final double scrollOffset;
  final Color activeColor;
  const _FloatingAppBar({required this.scrollOffset, required this.activeColor});

  @override
  Widget build(BuildContext context) {
    final double opacity = (1.0 - (scrollOffset / 60)).clamp(0.0, 1.0);
    if (opacity == 0) return const SizedBox.shrink();
    return Opacity(
      opacity: opacity,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          /*gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [activeColor, activeColor.withOpacity(0.0)],
            stops: const [0.6, 1.0],
          ),*/
          color: activeColor,
        ),
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('John Smith',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.3,
                              shadows: [Shadow(color: Colors.black26, blurRadius: 6)])),
                      const SizedBox(height: 1),
                      Row(children: const [
                        Icon(Icons.location_on_rounded, color: Colors.white70, size: 13),
                        SizedBox(width: 3),
                        Text('ABC, xyz 221012',
                            style: TextStyle(color: Colors.white70, fontSize: 12)),
                        Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white70, size: 15),
                      ]),
                    ],
                  ),
                ),
                Stack(children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.18),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white24)),
                    child: const Icon(Icons.notifications_outlined, color: Colors.white, size: 20),
                  ),
                  Positioned(
                    top: 6, right: 6,
                    child: Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(color: Color(0xFFFF5722), shape: BoxShape.circle),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  HERO BACKGROUND
// ═══════════════════════════════════════════════════════════════════
class _HeroBg extends StatelessWidget {
  final Color tabColor;
  const _HeroBg({required this.tabColor});

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    return SizedBox(
      // height: topPadding + 64,
      height: topPadding + 12,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          /*gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [tabColor, tabColor.withOpacity(0.8)],
          ),*/
          color: tabColor
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SECTION HEADER
// ═══════════════════════════════════════════════════════════════════
class _SectionHeader extends StatelessWidget {
  final String title;
  final bool showViewAll;
  const _SectionHeader({required this.title, this.showViewAll = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Row(
        children: [
          Expanded(
            child: Text(title,
                style: const TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF1A1A1A))),
          ),
          if (showViewAll) ...[
            Text('View All',
                style: TextStyle(fontSize: 13, color: Colors.blue.shade700, fontWeight: FontWeight.w600)),
            Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Colors.blue.shade700),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PRODUCT CARD  — matches reference exactly:
//  • Yellow off badge top-left
//  • "QUALITY CHECKED" vertical strip (right side) for select items
//  • Image in center
//  • ADD button (outlined)
//  • Name, weight, price row
//  • Optional lock + "₹XX OFFER" badge (isOfferPrice)
// ═══════════════════════════════════════════════════════════════════
class _ProductCard extends StatelessWidget {
  final ProductItem product;
  const _ProductCard({required this.product, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Image area with badges ──────────────────────────
          SizedBox(
            height: 140,
            child: Stack(
              children: [
                // Product image
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Image.network(
                      product.imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) =>
                          Icon(Icons.inventory_2_outlined, color: Colors.grey.shade300, size: 48),
                    ),
                  ),
                ),
                // Off badge — top left
                Positioned(
                  top: 8, left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFC107),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text('${product.off}\nOFF',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            height: 1.1)),
                  ),
                ),
              ],
            ),
          ),

          // ── ADD button ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Container(
              width: double.infinity,
              height: 34,
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF1565C0), width: 1.5),
                borderRadius: BorderRadius.circular(8),
              ),
              alignment: Alignment.center,
              child: const Text('ADD',
                  style: TextStyle(
                      color: Color(0xFF1565C0),
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      letterSpacing: 1.0)),
            ),
          ),
          const SizedBox(height: 6),

          // ── Weight ─────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(product.weight,
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ),
          const SizedBox(height: 2),

          // ── Name ───────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(product.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF1A1A1A))),
          ),
          const SizedBox(height: 4),

          // ── Price row ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: product.isOfferPrice
                ? Row(
              children: [
                Text(product.mrp,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1A1A1A))),
                const SizedBox(width: 6),
                Expanded(
                  child: Container(
                    height: 28,
                    decoration: BoxDecoration(
                      color: const Color(0xFF5C35C9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.lock, color: Colors.white, size: 12),
                        const SizedBox(width: 3),
                        Text(product.price,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(width: 2),
                        const Text('OFFER',
                            style: TextStyle(
                                color: Colors.white70,
                                fontSize: 8,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
              ],
            )
                : Row(
              children: [
                Text(product.price,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1A1A1A))),
                const SizedBox(width: 6),
                Text(product.mrp,
                    style: const TextStyle(
                        fontSize: 11,
                        decoration: TextDecoration.lineThrough,
                        color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PRODUCT ROW  (horizontal scroll)
// ═══════════════════════════════════════════════════════════════════
class _ProductRow extends StatelessWidget {
  final List<ProductItem> products;
  const _ProductRow({required this.products});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 270,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: products.length,
        itemBuilder: (_, i) => _ProductCard(product: products[i]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  FRUIT & VEG CATEGORY CARD  — large image with title overlay
//  Matches reference: photo background, dark text overlay at bottom
// ═══════════════════════════════════════════════════════════════════
class _FruitVegCard extends StatelessWidget {
  final CategoryItem cat;
  const _FruitVegCard({required this.cat});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: cat.bgColor,
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            cat.imageUrl,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: cat.bgColor,
              child: Icon(Icons.eco_outlined, size: 48, color: Colors.green.shade700),
            ),
          ),
          // Gradient overlay bottom
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withOpacity(0.55)],
                ),
              ),
            ),
          ),
          // Title
          Positioned(
            left: 10, right: 10, bottom: 8,
            child: Text(cat.title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    shadows: [Shadow(color: Colors.black45, blurRadius: 4)])),
          ),
        ],
      ),
    );
  }
}

class _FruitVegGrid extends StatelessWidget {
  final List<CategoryItem> categories;
  const _FruitVegGrid({required this.categories});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: categories
            .map((cat) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              right: cat == categories.last ? 0 : 8,
            ),
            child: AspectRatio(
              aspectRatio: 0.8,
              child: _FruitVegCard(cat: cat),
            ),
          ),
        ))
            .toList(),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  STANDARD CATEGORY GRID  — 4-col, icon + text below
// ═══════════════════════════════════════════════════════════════════
class _StandardCategoryGrid extends StatelessWidget {
  final List<CategoryItem> categories;
  const _StandardCategoryGrid({required this.categories});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.75,
        crossAxisSpacing: 8,
        mainAxisSpacing: 10,
      ),
      itemCount: categories.length,
      itemBuilder: (_, i) {
        final cat = categories[i];
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: cat.bgColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Image.network(
                    cat.imageUrl,
                    width: 46, height: 46,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) =>
                        Icon(Icons.category_outlined, size: 36, color: Colors.grey.shade400),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(cat.title,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: const TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w600, color: Color(0xFF1A1A1A))),
          ],
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SHOP BY STORE  — 4-col circular images
// ═══════════════════════════════════════════════════════════════════
class _StoreGrid extends StatelessWidget {
  final List<StoreItem> stores;
  const _StoreGrid({required this.stores});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.78,
        crossAxisSpacing: 8,
        mainAxisSpacing: 12,
      ),
      itemCount: stores.length,
      itemBuilder: (_, i) {
        final store = stores[i];
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey.shade100),
              child: ClipOval(
                child: Image.network(
                  store.imageUrl, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      Icon(Icons.store_outlined, size: 28, color: Colors.grey.shade400),
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(store.title,
                textAlign: TextAlign.center, maxLines: 2,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
          ],
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PROMO BANNER  — full-bleed image with text overlay
// ═══════════════════════════════════════════════════════════════════
class _PromoBanner extends StatelessWidget {
  final BannerItem banner;
  const _PromoBanner({required this.banner});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      height: 145,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: banner.bgColor,
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            banner.imageUrl,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: banner.bgColor),
          ),
          // Gradient left-side text overlay
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [banner.bgColor.withOpacity(0.85), Colors.transparent],
                stops: const [0.0, 0.6],
              ),
            ),
          ),
          if (banner.title != null)
            Positioned(
              left: 16, top: 0, bottom: 0,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(banner.title!,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: banner.bgColor == const Color(0xFF1B5E20)
                              ? Colors.yellowAccent
                              : const Color(0xFF1A1A1A),
                          height: 1.2)),
                  if (banner.subtitle != null) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: banner.bgColor == const Color(0xFF1B5E20)
                            ? Colors.yellowAccent
                            : const Color(0xFF1A1A1A),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(banner.subtitle!,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: banner.bgColor == const Color(0xFF1B5E20)
                                  ? Colors.black
                                  : Colors.white)),
                    ),
                  ]
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  FEATURED CARDS ROW  (Factory Sale, Price Drop, etc.)
// ═══════════════════════════════════════════════════════════════════
const _kFeaturedCards = [
  ('Factory Sale\nUpto 70% OFF', Color(0xFFFF8F00)),
  ('Price Drop\n% Deals',        Color(0xFFE53935)),
  ('Hot & Crispy\nSnacks',       Color(0xFF795548)),
  ('Fresh\nArrivals',            Color(0xFF43A047)),
];

class _FeaturedCardsRow extends StatelessWidget {
  const _FeaturedCardsRow();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _kFeaturedCards.length,
        itemBuilder: (_, i) {
          final (label, color) = _kFeaturedCards[i];
          return Container(
            width: 130,
            margin: const EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            alignment: Alignment.center,
            child: Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    color: color.withOpacity(0.9))),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SECTION BUILDER  — all data from controller
// ═══════════════════════════════════════════════════════════════════
List<Widget Function(HomeController)> _buildSectionBuilders() {
  return [
    // 0: Handpicked
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Handpicked for You 💛', showViewAll: true),
      _ProductRow(products: ctrl.handpickedProducts),
    ]),

    // 1: Banner
        (ctrl) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: ctrl.banners.isNotEmpty ? _PromoBanner(banner: ctrl.banners[2]) : const SizedBox(),
    ),

    // 2: Cold Drinks
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 6),
      const _SectionHeader(title: 'Cold Drinks & Juices', showViewAll: true),
      _ProductRow(products: ctrl.coldDrinksProducts),
    ]),

    // 3: Featured this Week
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Featured this Week'),
      const _FeaturedCardsRow(),
    ]),

    // 4: Deals
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Deals You Cannot Miss!', showViewAll: true),
      _ProductRow(products: ctrl.dealsProducts),
    ]),

    // 5: Fruits & Veg — LARGE IMAGE CARD UI
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Fruits & Vegetables'),
      _FruitVegGrid(categories: ctrl.fruitVegCategories),
    ]),

    // 6: Dairy — 4-col standard
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Dairy & Breakfast'),
      _StandardCategoryGrid(categories: ctrl.dairyCategories),
    ]),

    // 7: Grocery — 4-col standard (2 rows = 8 items)
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Grocery'),
      _StandardCategoryGrid(categories: ctrl.groceryCategories),
    ]),

    // 8: Snacks — 4-col
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Snacks & Drinks'),
      _StandardCategoryGrid(categories: ctrl.snacksCategories),
    ]),

    // 9: Beauty — 4-col
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Beauty & Personal Care'),
      _StandardCategoryGrid(categories: ctrl.beautyCategories),
    ]),

    // 10: Cleaning — 4-col
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Cleaning Essentials'),
      _StandardCategoryGrid(categories: ctrl.cleaningCategories),
    ]),

    // 11: Shop By Store
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      const _SectionHeader(title: 'Shop By Store'),
      _StoreGrid(stores: ctrl.stores),
    ]),

    // 12: Banner
        (ctrl) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: ctrl.banners.length > 1 ? _PromoBanner(banner: ctrl.banners[1]) : const SizedBox(),
    ),

    // 13: Best Selling
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 6),
      const _SectionHeader(title: 'Best Selling', showViewAll: true),
      _ProductRow(products: ctrl.bestSellingProducts),
    ]),

    // 14: Banner
        (ctrl) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: ctrl.banners.isNotEmpty ? _PromoBanner(banner: ctrl.banners[0]) : const SizedBox(),
    ),

    // 15: You May Also Like
        (ctrl) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 6),
      const _SectionHeader(title: 'You May Also Like', showViewAll: true),
      _ProductRow(products: ctrl.youMayLikeProducts),
      const SizedBox(height: 80),
    ]),
  ];
}

// ═══════════════════════════════════════════════════════════════════
//  HOME SCREEN
// ═══════════════════════════════════════════════════════════════════
class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scrollOffset = ValueNotifier<double>(0.0);
    final selectedTab  = ValueNotifier<int>(0);
    final scrollCtrl   = ScrollController();
    final sectionBuilders = _buildSectionBuilders();

    scrollCtrl.addListener(() {
      scrollOffset.value = scrollCtrl.offset;
      if (scrollCtrl.position.pixels >= scrollCtrl.position.maxScrollExtent - 300) {
        controller.loadMoreIfNeeded();
      }
    });

    final double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: GetBuilder<HomeController>(
        builder: (ctrl) {
          final tabs = ctrl.tabs;
          final Color activeColor = ctrl.activeColor;

          return ListenableBuilder(
            listenable: Listenable.merge([scrollOffset, selectedTab]),
            builder: (context, _) {
              final offset = scrollOffset.value;
              final idx    = selectedTab.value;

              return Stack(
                children: [
                  CustomScrollView(
                    controller: scrollCtrl,
                    slivers: [
                      // 1. Hero
                      SliverToBoxAdapter(child: _HeroBg(tabColor: activeColor)),

                      // 2. Pinned header
                      SliverPersistentHeader(
                        pinned: true,
                        delegate: _PinnedHeaderDelegate(
                          controller: ctrl,
                          scrollOffset: offset,
                          selectedTab: idx,
                          tabs: tabs,
                          statusBarHeight: statusBarHeight,
                          onTabSelected: (i) {
                            selectedTab.value = i;
                            ctrl.changeTab(i);
                          },
                        ),
                      ),

                      // 3. Feed — sections built with controller data
                      SliverList(
                        delegate: SliverChildBuilderDelegate(
                              (context, i) => sectionBuilders[i](ctrl),
                          childCount: sectionBuilders.length,
                        ),
                      ),

                      // 4. Infinite scroll indicator
                      SliverToBoxAdapter(
                        child: ctrl.isLoadingMore
                            ? Padding(
                            padding: const EdgeInsets.all(20),
                            child: Center(
                                child: CircularProgressIndicator(color: activeColor)))
                            : const SizedBox(height: 40),
                      ),
                    ],
                  ),

                  // Floating AppBar
                  Positioned(
                    top: 0, left: 0, right: 0,
                    child: _FloatingAppBar(scrollOffset: offset, activeColor: activeColor),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}