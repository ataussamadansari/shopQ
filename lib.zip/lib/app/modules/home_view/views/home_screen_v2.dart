import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';

// ══════════════════════════════════════════════════════════════
//  TAB MODEL
// ══════════════════════════════════════════════════════════════
class QuickTab {
  final String title;
  final IconData icon;
  final Color bgColor;      // header background when this tab is active
  final Color accentColor;  // indicator line / selected tint color

  const QuickTab({
    required this.title,
    required this.icon,
    required this.bgColor,
    required this.accentColor,
  });
}

// ── Default tabs matching the reference screenshots ──────────
const List<QuickTab> kDefaultTabs = [
  QuickTab(title: 'All',     icon: Icons.shopping_bag_outlined,  bgColor: Colors.blue, accentColor: Colors.blueAccent),
  QuickTab(title: 'Ramadan', icon: Icons.nightlight_round,       bgColor: Colors.green, accentColor: Colors.greenAccent),
  QuickTab(title: 'Deals',   icon: Icons.discount_outlined,      bgColor: Colors.orange, accentColor: Colors.orangeAccent),
  QuickTab(title: 'Fresh',   icon: Icons.eco_outlined,           bgColor: Colors.pink, accentColor: Colors.pinkAccent),
  QuickTab(title: 'Rice',    icon: Icons.grass_outlined,         bgColor: Colors.yellow, accentColor: Colors.yellowAccent),
];

// ══════════════════════════════════════════════════════════════
//  PINNED HEADER DELEGATE  (Search + Quick Tabs)
//  Background: transparent at 0 scroll → tab color at ~80px scroll
//
//  ✅ SafeArea fix:
//  SliverPersistentHeaderDelegate.minExtent / maxExtent are called
//  BEFORE build(), so they cannot call MediaQuery. The fix is to
//  pass the statusBarHeight in from the parent widget (where
//  MediaQuery IS available) and include it in the extents.
//
//  Content height breakdown (fixed part):
//    10px top padding  +  46px search  +  4px gap  +  58px tabs  =  118px
//  Total extent = statusBarHeight + 118
// ══════════════════════════════════════════════════════════════
class _PinnedHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double scrollOffset;
  final int selectedTab;
  final ValueChanged<int> onTabSelected;
  final List<QuickTab> tabs;

  /// ← KEY FIX: receive status-bar height from parent
  final double statusBarHeight;

  const _PinnedHeaderDelegate({
    required this.scrollOffset,
    required this.selectedTab,
    required this.onTabSelected,
    required this.tabs,
    required this.statusBarHeight, // ← pass MediaQuery.of(context).padding.top
  });

  // Fixed content height (search + gap + tabs + inner padding)
  static const double _contentHeight = 118.0;
  static const double _innerTopPad   = 10.0;

  // ✅ Both extents include the status-bar height so the header
  //    is never taller/shorter than the visible area it occupies.
  @override double get minExtent => statusBarHeight + _contentHeight;
  @override double get maxExtent => statusBarHeight + _contentHeight;

  double get _t => (scrollOffset / 80).clamp(0.0, 1.0);
  double get _extraTopPad => statusBarHeight * _t;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final tabColor = tabs[selectedTab].bgColor;
    final bg = Color.lerp(tabColor, tabColor, _t)!;
    final isScrolled = _t > 0.05;

    return Container(
      color: bg,
      // ✅ Top padding = statusBarHeight (replaces hard-coded 10px).
      //    This pushes search bar below the system status bar at all times.
      padding: EdgeInsets.fromLTRB(12, _innerTopPad + _extraTopPad, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Search Bar ─────────────────────────────────────
          Container(
            height: 46,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: isScrolled
                  ? [BoxShadow(color: Colors.black12, blurRadius: 6, offset: const Offset(0, 2))]
                  : [],
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.search, color: Color(0xFF9E9E9E), size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Search for "Milk"',
                    style: TextStyle(color: Colors.grey.shade400, fontSize: 14),
                  ),
                ),
                Container(
                    margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                    width: 1,
                    color: Colors.grey.shade300),
                const Icon(Icons.mic_outlined, color: Color(0xFF9E9E9E), size: 20),
                const SizedBox(width: 12),
              ],
            ),
          ),

          const SizedBox(height: 4),

          // ── Quick Tabs ─────────────────────────────────────
          SizedBox(
            height: 58,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: tabs.length,
              itemBuilder: (context, i) {
                final tab = tabs[i];
                final bool isSel = i == selectedTab;

                final Color iconColor = isScrolled
                    ? (isSel ? Colors.white : Colors.white70)
                    : (isSel ? Colors.white : Colors.black54);
                final Color labelColor = isScrolled
                    ? (isSel ? Colors.white : Colors.white70)
                    : (isSel ? Colors.white : Colors.black87);
                final Color lineColor = isScrolled ? Colors.white : tab.accentColor;


                /*final Color iconColor = isScrolled
                    ? (isSel ? Colors.white : Colors.white70)
                    : (isSel ? tab.accentColor : Colors.black54);
                final Color labelColor = isScrolled
                    ? (isSel ? Colors.white : Colors.white70)
                    : (isSel ? tab.accentColor : Colors.black87);
                final Color lineColor = isScrolled ? Colors.white : tab.accentColor;*/

                return GestureDetector(
                  onTap: () => onTabSelected(i),
                  child: Container(
                    margin: const EdgeInsets.only(right: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // icon + optional highlight ring when selected+scrolled
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: isSel && isScrolled
                                ? Colors.white.withOpacity(0.2)
                                : Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(tab.icon, size: 22, color: iconColor),
                        ),
                        const SizedBox(height: 1),
                        Text(tab.title,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: isSel ? FontWeight.w700 : FontWeight.w400,
                              color: labelColor,
                            )),
                        const SizedBox(height: 2),
                        // bottom indicator
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: 3,
                          width: isSel ? 26 : 0,
                          decoration: BoxDecoration(
                            color: lineColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(_PinnedHeaderDelegate old) =>
      old.scrollOffset != scrollOffset ||
          old.selectedTab != selectedTab ||
          old.statusBarHeight != statusBarHeight;
}

// ══════════════════════════════════════════════════════════════
//  APP BAR: Username + Location  (fades OUT as user scrolls)
// ══════════════════════════════════════════════════════════════
class _FloatingAppBar extends StatelessWidget {
  final double scrollOffset;
  const _FloatingAppBar({required this.scrollOffset});

  @override
  Widget build(BuildContext context) {
    final double opacity = (1.0 - (scrollOffset / 60)).clamp(0.0, 1.0);
    if (opacity == 0) return const SizedBox.shrink();

    return Opacity(
      opacity: opacity,
      child: SafeArea(
        bottom: false,
        // ✅ SafeArea is the RIGHT place here — it insets by status bar height
        //    automatically, so name+location never overlaps system UI.
        //    We do NOT use SafeArea in the pinned delegate (we pass the height
        //    explicitly instead), because SliverPersistentHeaderDelegate cannot
        //    call MediaQuery inside minExtent/maxExtent.
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              // Name + Location
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'John Smith',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.3,
                        shadows: [Shadow(color: Colors.black26, blurRadius: 6)],
                      ),
                    ),
                    const SizedBox(height: 1),
                    Row(
                      children: const [
                        Icon(Icons.location_on_rounded, color: Colors.white70, size: 13),
                        SizedBox(width: 3),
                        Text('ABC, xyz 221012',
                            style: TextStyle(color: Colors.white70, fontSize: 12)),
                        Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white70, size: 15),
                      ],
                    ),
                  ],
                ),
              ),
              // Bell
              Stack(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.notifications_outlined,
                        color: Colors.white, size: 20),
                  ),
                  Positioned(
                    top: 6, right: 6,
                    child: Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                          color: Color(0xFFFF5722), shape: BoxShape.circle),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  HERO BACKGROUND
//  ► Replace the AnimatedContainer with:
//    Image.asset('assets/gifs/eid.gif', fit: BoxFit.cover)
//    Lottie.asset('assets/lottie/hero.json')
// ══════════════════════════════════════════════════════════════
class _HeroBg extends StatelessWidget {
  final Color tabColor;
  const _HeroBg({required this.tabColor});

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    // ✅ Hero height = status bar + appbar content (name + location ≈ 64px)
    //    This matches exactly how tall _FloatingAppBar renders,
    //    so when it fades out the hero and the pinned header line up perfectly.
    const double appBarContentHeight = 64.0;
    return SizedBox(
      height: topPadding + appBarContentHeight,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
        // ──────────────────────────────────────────────
        // SWAP THIS with Image.asset / Lottie / NetworkImage:
        //
        //   child: Image.asset('assets/gifs/eid.gif',
        //     width: double.infinity, fit: BoxFit.cover)
        //
        // ──────────────────────────────────────────────
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [tabColor, tabColor/*.withOpacity(0.65)*/],
          ),
        ),
        child: Stack(
          children: [
            // Subtle dot overlay for depth
            Opacity(
              opacity: 0.07,
              child: CustomPaint(
                painter: _DotGrid(),
                child: const SizedBox.expand(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DotGrid extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = Colors.white;
    const s = 18.0;
    for (double x = 0; x < size.width; x += s) {
      for (double y = 0; y < size.height; y += s) {
        canvas.drawCircle(Offset(x, y), 1.5, p);
      }
    }
  }
  @override bool shouldRepaint(_) => false;
}

// ══════════════════════════════════════════════════════════════
//  HOME SCREEN
// ══════════════════════════════════════════════════════════════
class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scrollOffset  = ValueNotifier<double>(0.0);
    final selectedTab   = ValueNotifier<int>(0);
    final scrollCtrl    = ScrollController();

    scrollCtrl.addListener(() => scrollOffset.value = scrollCtrl.offset);

    // Use controller tabs if available, else fallback to defaults
    // final tabs = controller.tabs  // your model list → convert to QuickTab
    final tabs = kDefaultTabs;

    // ✅ Read statusBarHeight here — MediaQuery IS available in build().
    //    We pass it into the delegate so minExtent/maxExtent can use it.
    final double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.white,
      // ✅ Do NOT wrap body in SafeArea — we handle insets manually so
      //    the hero background can bleed behind the status bar correctly.
      body: ListenableBuilder(
        listenable: Listenable.merge([scrollOffset, selectedTab]),
        builder: (context, _) {
          final offset   = scrollOffset.value;
          final tabIdx   = selectedTab.value;
          final activeTab = tabs[tabIdx];

          return Stack(
            children: [
              // ── Main scroll ────────────────────────────────
              CustomScrollView(
                controller: scrollCtrl,
                slivers: [

                  // 1. Hero (image / gif / lottie / color)
                  SliverToBoxAdapter(
                    child: _HeroBg(tabColor: activeTab.bgColor),
                  ),

                  // 2. Pinned: Search + Tabs
                  SliverPersistentHeader(
                    pinned: true,
                    delegate: _PinnedHeaderDelegate(
                      scrollOffset: offset,
                      selectedTab: tabIdx,
                      tabs: tabs,
                      statusBarHeight: statusBarHeight, // ← ✅ fix passed here
                      onTabSelected: (i) {
                        selectedTab.value = i;
                        scrollOffset.notifyListeners();
                      },
                    ),
                  ),

                  // 3. Content
                  SliverToBoxAdapter(
                    child: _PageContent(tabIndex: tabIdx, tabs: tabs),
                  ),
                ],
              ),

              // ── Floating AppBar: name+location (fades on scroll) ──
              Positioned(
                top: 0, left: 0, right: 0,
                child: _FloatingAppBar(scrollOffset: offset),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  SAMPLE PAGE CONTENT
// ══════════════════════════════════════════════════════════════
class _PageContent extends StatelessWidget {
  final int tabIndex;
  final List<QuickTab> tabs;
  const _PageContent({required this.tabIndex, required this.tabs});

  static const _bannerColors = [
    Color(0xFFFFF3E0), Color(0xFFE8F5E9),
    Color(0xFFFFF8E1), Color(0xFFE8F5E9), Color(0xFFF1F8E9),
  ];
  static const _bannerTexts = [
    'Get FLAT ₹50 OFF\non your first order!',
    'Ramadan Special\nEssentials at best prices',
    'Factory Sale\nUpto 70% OFF — Shop Now',
    'Farm Fresh\nDelivered in 10 mins',
    'Premium Rice\nDirect from farms',
  ];

  @override
  Widget build(BuildContext context) {
    final activeTab = tabs[tabIndex];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 12),

        // Promo Banner
        AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          margin: const EdgeInsets.symmetric(horizontal: 12),
          height: 108,
          decoration: BoxDecoration(
            color: _bannerColors[tabIndex],
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 3))],
          ),
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  _bannerTexts[tabIndex],
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800,
                      color: Color(0xFF212121), height: 1.35),
                ),
              ),
              Positioned(
                right: 14, bottom: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(
                    color: activeTab.accentColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text('Shop Now',
                      style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // Section
        _SectionHeader(title: 'Featured this Week'),
        _HorizontalFeatureCards(accentColor: activeTab.accentColor),
        const SizedBox(height: 20),

        _SectionHeader(title: 'Deals You Cannot Miss!', showViewAll: true),
        _ProductGrid(accentColor: activeTab.accentColor),
        const SizedBox(height: 32),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final bool showViewAll;
  const _SectionHeader({required this.title, this.showViewAll = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Row(
        children: [
          Expanded(child: Text(title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF1A1A1A)))),
          if (showViewAll) ...[
            Text('View All', style: TextStyle(fontSize: 13, color: Colors.blue.shade700, fontWeight: FontWeight.w600)),
            Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Colors.blue.shade700),
          ],
        ],
      ),
    );
  }
}

class _HorizontalFeatureCards extends StatelessWidget {
  final Color accentColor;
  const _HorizontalFeatureCards({required this.accentColor});

  @override
  Widget build(BuildContext context) {
    final items = ['Factory\nSale 70%', 'Price\nDrop %', 'Hot & Crispy\nSnacks', 'Fresh\nArrivals'];
    return SizedBox(
      height: 95,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: items.length,
        itemBuilder: (_, i) => Container(
          width: 120,
          margin: const EdgeInsets.only(right: 10),
          decoration: BoxDecoration(
            color: accentColor.withOpacity(0.09),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accentColor.withOpacity(0.25)),
          ),
          alignment: Alignment.center,
          child: Text(items[i],
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: accentColor)),
        ),
      ),
    );
  }
}

class _ProductGrid extends StatelessWidget {
  final Color accentColor;
  const _ProductGrid({required this.accentColor});

  static const _products = [
    ('Coconut Oil 250ml', '₹230', '₹279', '18%'),
    ('Desi Ghee 500ml', '₹702', '₹1405', '50%'),
    ('Red Chilli Pickle 200g', '₹77', '₹80', '₹3'),
    ('Full Cream Milk 1L', '₹62', '₹72', '14%'),
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, childAspectRatio: 0.75,
        crossAxisSpacing: 10, mainAxisSpacing: 10,
      ),
      itemCount: _products.length,
      itemBuilder: (_, i) {
        final (name, price, mrp, off) = _products[i];
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE0E0E0)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6, offset: const Offset(0, 2))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                      color: const Color(0xFFFFC107), borderRadius: BorderRadius.circular(4)),
                  child: Text('$off OFF',
                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
              ),
              Expanded(
                child: Center(
                  child: Icon(Icons.inventory_2_outlined, color: Colors.grey.shade300, size: 44),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Container(
                  width: double.infinity,
                  height: 32,
                  decoration: BoxDecoration(
                    border: Border.all(color: accentColor),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  alignment: Alignment.center,
                  child: Text('ADD',
                      style: TextStyle(color: accentColor, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: 0.5)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 2),
                child: Text(name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF212121))),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
                child: Row(
                  children: [
                    Text(price,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF1A1A1A))),
                    const SizedBox(width: 6),
                    Text(mrp,
                        style: const TextStyle(fontSize: 11, decoration: TextDecoration.lineThrough, color: Colors.grey)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}