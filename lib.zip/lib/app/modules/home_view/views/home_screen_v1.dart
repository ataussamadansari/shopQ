import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (controller) {
        return Scaffold(
          body: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Container(
                  padding: EdgeInsets.only(
                    left: 16.0,
                    right: 16.0,
                    bottom: 8.0,
                  ),
                  decoration: BoxDecoration(
                    // color: Colors.blue
                    image: DecorationImage(
                      image: AssetImage("assets/gifs/eid.gif"),
                      fit: BoxFit.fill,
                      filterQuality: FilterQuality.medium,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 40),
                      //App bar
                      Text(
                        "John Smith",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w500,
                          height: 0.5,
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            "ABC, xyz 221012",
                            style: TextStyle(fontSize: 12, height: 0.5),
                          ),
                          Icon(Icons.keyboard_arrow_down),
                        ],
                      ),
                      SizedBox(height: 8),

                      //Search bar
                      Container(
                        height: 52,
                        alignment: AlignmentGeometry.centerLeft,
                        padding: EdgeInsets.all(12),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Text(
                          "Search here ...",
                          maxLines: 1,
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                      SizedBox(height: 16),

                      // Tabs
                      SizedBox(
                        height: 60,
                        width: double.infinity,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: controller.tabs.length,
                          itemBuilder: (context, index) {
                            final tab = controller.tabs[index];
                            final isSelected =
                                controller.selectedIndex == index;

                            return GestureDetector(
                              onTap: () => controller.changeTab(index),
                              child: Stack(
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 12,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Image.network(
                                          tab.image,
                                          height: 30,
                                          width: 30,
                                          fit: BoxFit.contain,
                                        ),

                                        Text(
                                          tab.title,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: isSelected
                                                ? Colors.black
                                                : Colors.black87,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  /// 🔥 Bottom line indicator
                                  Positioned(
                                    bottom: 0,
                                    left: 8,
                                    right: 8,
                                    child: AnimatedContainer(
                                      duration: Duration(milliseconds: 250),
                                      height: 3,
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? Colors.black
                                            : Colors.transparent,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),

                      // Banner
                      SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Container(height: 1000, width: 200, color: Colors.blue),
              ),
            ],
          ),
        );
      },
    );
  }
}
